//%attributes = {"invisible":true}
// Method: aa4D_M_Host_Stored_Proc_RemCall
// (Thomas.Schlumberger@4d.com, March 2022)

// This is a calling method to launch the remote stored procedure.
// The stored procedure will have to be killed via the Runtime explorer

var $pathLocalFolder : Text
var $NP : Integer
var $Nb_Minutes : Real
var $oPathFolder : Object

// Custom settings here
$Nb_Minutes:=10  // 10 minutes... or 1/4  // every 15 seconds, for testing

$oPathFolder:=Folder:C1567(fk desktop folder:K87:19; *)  // Create or use this folder on the desktop
$pathLocalFolder:=$oPathFolder.platformPath+"Folder_reports"
// or set another location, also via aa4D_M_Host_Change_Folder

$pathLocalFolder:="bibi"

$NP:=New process:C317("aa4D_M_Host_Stored_Proc_Remote"; 0; "$4DIR_Stored_Procedure"; $pathLocalFolder; $Nb_Minutes; *)