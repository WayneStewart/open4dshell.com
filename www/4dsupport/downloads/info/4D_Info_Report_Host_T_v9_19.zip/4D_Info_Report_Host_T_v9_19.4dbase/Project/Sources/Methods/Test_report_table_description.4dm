//%attributes = {"invisible":true}
// Method: Test_report_table_description
// This test method create 12 reports with the 12 different kind of content about the tables
// ---- 
C_BOOLEAN:C305(<>vb_4D_Info_Report_OK)
If (<>vb_4D_Info_Report_OK)
	var vl_Kind_Report : Integer
	var vt_Comment : Text
	For (vl_Kind_Report; -2; 9)  // Define the mode of the description of report (for tables), see documentation.
		vt_Comment:="Comment of the parameter value: "+String:C10(vl_Kind_Report)
		// -> vt_Comment insert the content of this variable in the "Comment" section.
		// 1 as first parameter: does not show the created report in a dialog. 
		EXECUTE METHOD:C1007("aa4D_NP_Util_CreateReport"; *; 1; vl_Kind_Report; ->vt_Comment)
		DELAY PROCESS:C323(Current process:C322; 3600)  // wait 60 seconds
	End for 
	ALERT:C41("Done")
	
End if 
