//%attributes = {"invisible":true}
// Method: aa4D_M_Host_Manage_Info_Report
// (Thomas.Schlumberger@4d.com, Dec 2014)

// Method called by a menu in Application mode (for Administration).
// (in this database, the menu "File / 4D_Info_Report").

C_BOOLEAN:C305(<>vb_4D_Info_Report_OK)
If (<>vb_4D_Info_Report_OK)  // inited in the On startup of the Host DB
	// Display the component dialog in 4D remote mode, for:
	// - choosing the criteria to display last report values in a local Compare dialog
	// - via the Manage button, check, start or stop the stored procedure on 4D Server
	EXECUTE METHOD:C1007("aa4D_NP_Report_Export_Display")
End if 
