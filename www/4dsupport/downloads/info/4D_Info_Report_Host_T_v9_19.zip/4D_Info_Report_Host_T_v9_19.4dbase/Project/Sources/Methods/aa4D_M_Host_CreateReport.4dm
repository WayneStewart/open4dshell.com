//%attributes = {"invisible":true}
// Method: aa4D_M_Host_CreateReport

C_BOOLEAN:C305(<>vb_4D_Info_Report_OK)
If (<>vb_4D_Info_Report_OK)
	var $FacelessMode : Integer  // = 0 : Show the dialog after the creation of the report
	// $FacelessMode = 1: Do not show a dialog after creating a report (like on 4D Server)
	
	EXECUTE METHOD:C1007("aa4D_NP_Util_CreateReport"; *; $FacelessMode)
End if 
