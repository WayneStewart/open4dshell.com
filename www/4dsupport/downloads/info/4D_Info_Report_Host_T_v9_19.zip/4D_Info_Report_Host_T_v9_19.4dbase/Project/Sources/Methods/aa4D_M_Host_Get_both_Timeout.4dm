//%attributes = {"invisible":true,"shared":true}
// Method: aa4D_M_Host_Get_both_Timeout
//(Thomas.Schlumberger@4d.com, modif Dec 2014)
//
// Method to include in your Host database, that will be called each time a report is created,
//
// IMPORTANT: This method must be shared by components and host database, with this same name.
//
// Note: since v4.9rC, if the shared method "aa4D_Host_GetDBParam" exists,
// this one is no longer required.
//
C_BOOLEAN:C305($0)  // Returns true if the method has been correctly executed
C_POINTER:C301($1; $2)  // pointers to the numeric variables that will get the values
C_LONGINT:C283($vl_4D_Server_Timeout; $vl_4D_Remote_Timeout)

// expressed in number of minutes
$vl_4D_Server_Timeout:=Get database parameter:C643(4D Server timeout:K37:13)  // =13
$vl_4D_Remote_Timeout:=Get database parameter:C643(4D Remote mode timeout:K37:14)  // =14

If (Count parameters:C259>=2)
	$1->:=$vl_4D_Server_Timeout
	$2->:=$vl_4D_Remote_Timeout
	$0:=True:C214
Else   // Added Dec. 2014
	$0:=True:C214  // Added Dec. 2014
End if 
