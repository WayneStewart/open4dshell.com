//%attributes = {"invisible":true}
C_BOOLEAN:C305(<>vb_4D_Info_Report_OK)