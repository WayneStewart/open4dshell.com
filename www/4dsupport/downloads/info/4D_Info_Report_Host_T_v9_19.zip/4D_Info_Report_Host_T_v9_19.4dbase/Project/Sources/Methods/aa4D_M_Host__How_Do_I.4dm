//%attributes = {"invisible":true}
// Method: aa4D_M_Host__How_Do_I
// (Thomas.Schlumberger@4d.com, April 7, 2022, version 8)
//
// If you are using the Information component (4D_Info_Report_v4.9rC or later),
// Some specific Host methods will be tested by the component,
// If they exist and are shared, they will be used to communicate with the Host database.
// 
// Note: if the component is removed, these methods will not disturb the behavior of the Host database, so you can be integrated in your Host database without drawback.
// 
// at least copy (by Drag and Drop) these seven methods in your Host database:
// -  "aa4D_H__Startup"   // to be called in the On Startup method
// -  "aa4D_H_On_Server_Startup"  // to be called in the On Server Startup method
// -  "aa4D_Host_GetDBParam"  (new shared method now usable with all versions of 4D).
// -  "aa4D_M_Host_Manage_Info_Report" 
// -  "aa4D_M_Host_Attention_Reported"  
// -  "aa4D_M_Host_Allow_Report_access"
// -  "aa4D_M_Host_SP_Scheduler" // Mandatory if using "aa4D_H_On_Server_Startup"

// Two added example methods in this version 8 (2022) of the Host template:
// -  "aa4D_M_Host_Stored_Proc_Remote" (to launch a stored procedure in remote mode)
// -  "aa4D_M_Host_Stored_Proc_RemCall" (minimal code example to launch this stored proc.)


// You must keep their original name, and set "shared by component and host database" 

// Reminder: to use the component "4D_Info_Report_v4",
// just add it to the "Components" folder of the Host database or the 4D Application.
// (if this "Components" folder does not exist, just create it).
// 
// This database code is compatible with 4D v12 and later database:
// To use these methods with a Host database:
// just convert a copy of this Template database with your current 4D version
// before drag & dropping these methods into the Host database.
//
// If you use Compiler_methods, change the settings of the compiler
// to generate the Compiler expected methods.

