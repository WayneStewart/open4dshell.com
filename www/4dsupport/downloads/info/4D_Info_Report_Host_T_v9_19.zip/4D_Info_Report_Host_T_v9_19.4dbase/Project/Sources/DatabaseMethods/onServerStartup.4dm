// Code to add at the end of your On Server Startup method:
If (Shift down:C543)
	TRACE:C157
	// To start the stored procedure on the Server
	// that create a report every N minute(s)
	aa4D_H_On_Server_Startup
	// (customize this method is you want to change the default settings).
End if 