//%attributes = {"invisible":true}
// Method: aa4D_M_Host_Template_About
var $txt : Text
$txt:="'4D_Info_Report_Host_Template_v9' \r contains some projet methods, that can"
$txt:=$txt+"\r be integrated in your Host database version 19 or later,"
$txt:=$txt+"\r to improve the use of the component '4D_Info_Report'."

$txt:=$txt+"\r\r (This library can also be compiled without the component installed)"
ALERT:C41($txt)
