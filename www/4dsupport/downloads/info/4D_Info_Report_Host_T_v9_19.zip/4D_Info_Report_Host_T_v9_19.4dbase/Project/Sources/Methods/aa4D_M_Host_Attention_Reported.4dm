//%attributes = {"invisible":true,"shared":true}
// Method: aa4D_M_Host_Attention_Reported, shared method
//
//  IMPORTANT: This method must keep it's original name
//  and be shared with components,
//  to be used by 4D_Info_Report.

#DECLARE($blb_Attentions : Blob)
var $content : Text
If (Count parameters:C259>=1)
	If (BLOB size:C605($blb_Attentions)>0)
		$content:=Convert to text:C1012($blb_Attentions; "UTF-8")
		// -- customize this part to handle or not the Attention received --
		If (Application type:C494#4D Server:K5:6)
			// ALERT($text)  // To verify that you have received something
		End if 
	End if 
End if 
