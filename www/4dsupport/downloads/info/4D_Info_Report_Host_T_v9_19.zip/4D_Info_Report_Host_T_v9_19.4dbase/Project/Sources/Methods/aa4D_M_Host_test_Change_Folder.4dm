//%attributes = {"invisible":true}
var $t : Text
$t:="C:\\Component Testing\\Subfolder\\Another folder\\"
aa4D_M_Host_Change_Folder($t)