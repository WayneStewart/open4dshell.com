//%attributes = {"invisible":true,"shared":true}
// Method: aa4D_M_Host_Info_Report_version
// (Thomas.schlumberger@4d.com  Mod Dec 2014)
// This method let you know the version of 4D_Info_Report

C_POINTER:C301($1)  // pointer to the text variable that will receive the information
C_TEXT:C284($vt_version)
C_BOOLEAN:C305(<>vb_4D_Info_Report_OK)
If (<>vb_4D_Info_Report_OK)  // inited in the On startup of the Host DB
	EXECUTE METHOD:C1007("aa4D_M_Get_Component_Version"; *; ->$vt_version)
	// $vt_version = "4.9rC (2015-08-21)"
	If (Count parameters:C259>=1)
		$1->:=$vt_version
	Else 
		ALERT:C41("Version: "+$vt_version)
	End if 
End if 