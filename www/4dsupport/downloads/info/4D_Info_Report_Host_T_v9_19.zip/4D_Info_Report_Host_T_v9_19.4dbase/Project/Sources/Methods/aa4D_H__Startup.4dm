//%attributes = {"invisible":true}
// Method: aa4D_H__Startup
// Method to execute in the On startup method of the Host database

C_BOOLEAN:C305(<>vb_4D_Info_Report_OK)
ARRAY TEXT:C222($at_Components; 0)
COMPONENT LIST:C1001($at_Components)
If (Find in array:C230($at_Components; "4D_Info_Report@")>0)  //  the component is loaded
	<>vb_4D_Info_Report_OK:=True:C214  // Set an Interprocess to avoid later multiple tests
End if 