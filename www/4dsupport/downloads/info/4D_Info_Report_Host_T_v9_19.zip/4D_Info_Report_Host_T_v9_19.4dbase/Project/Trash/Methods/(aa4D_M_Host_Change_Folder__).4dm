//%attributes = {"invisible":true}
// Method: aa4D_M_Host_Change_Folder
// (Thomas.Schlumberger@4d.com, February 2024, compatible v19)
#DECLARE($pathLocalFolder : Text)

var $vb_FolderPath_OK : Boolean
var $pathLocalFolder : Text
var $oPathFolder : Object

ARRAY TEXT:C222($at_Components; 0)
COMPONENT LIST:C1001($at_Components)
If (Find in array:C230($at_Components; "4D_Info_Report@")>0)  //  the component is loaded
	
	// $pathLocalFolder:="C:\\Component Testing\\Subfolder\\Another folder\\"
	
	If ((Length:C16($pathLocalFolder)>4) & (Position:C15(Folder separator:K24:12; $pathLocalFolder)>0))
		
		$oPathFolder:=Folder:C1567($pathLocalFolder; fk platform path:K87:2)
		If ($oPathFolder.exists=True:C214)
			$vb_FolderPath_OK:=True:C214
		Else 
			$oPathFolder.create()
			If ($oPathFolder.exists=True:C214)
				$vb_FolderPath_OK:=True:C214
			End if 
		End if 
	End if 
	
	If ($vb_FolderPath_OK=False:C215)
		
		If (Application type:C494#4D Server:K5:6)
			$pathLocalFolder:=Select folder:C670("Select a folder to store the created reports"; ""; Package open:K24:8)
			
			If (OK=0)  // dialog cancelled
				CONFIRM:C162("Create a folder 'Folder_reports' on the Desktop?")
				
				If (OK=1)
					$oPathFolder:=Folder:C1567(fk desktop folder:K87:19; *)
					$pathLocalFolder:=$oPathFolder.platformPath+"Folder_reports"
					
					// $vt_Folder_Pathname:="C:\\Component Testing\\Subfolder\\Another folder\\"
					
					$oPathFolder:=Folder:C1567($pathLocalFolder; fk platform path:K87:2)
					
					If ($oPathFolder.exists=False:C215)
						$oPathFolder.create()
					End if 
				End if 
			End if 
			
			If (OK=1)  // validation of the location of the folder, proceed
				
				// ---- set the new pathname for future reports ------
				EXECUTE METHOD:C1007("aa4D_M_Folder_Rep_SetPath_local"; $vb_FolderPath_OK; ->$pathLocalFolder)
				// Keep this path if you need to check it's content or reuse it later.
				
				// ----to Test the creation of a report in this Folder Pathname-----
				If (False:C215)  // replace by True if you want to test
					If ($oPathFolder.exists)  //  if this folder exists
						CONFIRM:C162("Create a report in this Local folder?\n"+$pathLocalFolder)
						If (OK=1)
							EXECUTE METHOD:C1007("aa4D_NP_Util_CreateReport"; *; 1)
							
						End if 
					End if 
					
					// ------ verify the changed pathname of the folder ----
					EXECUTE METHOD:C1007("aa4D_M_Folder_Rep_GetPath_local"; $vb_FolderPath_OK; ->$pathLocalFolder)
					// $vt_Folder_Pathname must correspond.
				End if 
			End if 
		End if 
	End if 
End if 