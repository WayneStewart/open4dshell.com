//%attributes = {"invisible":true,"shared":true}
// Method: aa4D_M_Host_Allow_Report_access
// (Thomas.Schlumberger@4d.com, October 31, 2012)
//
// Method to be included in the Host database, that will be called by the component  4D_Info_Report_v3,
//  IMPORTANT: This Host method must be shared (see method properties) to be used.
// 
// if a  user is executing a secured component method, for example to display the Manage dialog to:
// - Set/Stop/Change the sheduler of the stored procedure to create reports on 4D Server
// - Retrieve or delete reports created on 4D Server,
// This Host method will be executed to allow (or deny) the right to do this.

C_BLOB:C604($1)  // Blob sent by the component
C_BOOLEAN:C305($0)  // Allow access to this admin setting for the secured component's methods

C_BLOB:C604($vxBlob)
C_BOOLEAN:C305($Allow)
C_LONGINT:C283($Offset)

$Allow:=True:C214  // default answer.

If (Count parameters:C259>=1)
	If (Type:C295($1)=Is BLOB:K8:12)
		$vxBlob:=$1
		//---  in Unicode only, as the component is built in Unicode ----
		ARRAY TEXT:C222($at_infos; 0)
		BLOB TO VARIABLE:C533($vxBlob; $at_infos; $Offset)  // values from the local / remote user.
		// - ($at_infos{1}:=Current user)
		// - ($at_infos{2}:=(local) IP. address
		// - ($at_infos{3}:=Current machine)
		// - ($at_infos{4}:=Current machine owner)
		// - ($at_infos{5}:=Calling component method (optional)
		//
		// --- set your own conditions, depending of the 5 array elements ---
		// ...
		// ---- to deny access ---
		// $Allow:=False  ` default answer.
		// 
		If (Application type:C494#4D Server:K5:6)
			// ALERT("'aa4D_M_Host_Allow_Report_access' OK")  // to control that it is called
		End if 
	End if 
End if 
$0:=$Allow

