//%attributes = {"invisible":true}
// Method: aa4D_H_On_Server_Startup

// Method to execute in the On Server Startup database method.
// (beware that this method was named "aa4D_M_H_On_Server_Startup" before)

C_BOOLEAN:C305(<>vb_4D_Info_Report_OK)

aa4D_H__Startup  // (to init once <>vb_4D_Info_Report_OK)

If (Shift down:C543)
	TRACE:C157  // (to trace the execution of this method)
	
	If (Is compiled mode:C492)  // (Only if the Host database is compiled)
		// To start the stored procedure on the Server,
		// creating a report every N minutes
		If (<>vb_4D_Info_Report_OK)
			
			If (True:C214)
				aa4D_M_Host_SP_Scheduler(30)  // every 30 minutes, to be adjusted
				// (pass 0 to stop the stored procedure).
				//
			Else 
				// You can also decide to only create a single report every time the Server is started
				// (as the first report takes more time to build, so next ones will be much faster and less demanding) :
				EXECUTE METHOD:C1007("aa4D_NP_Util_CreateReport")
			End if 
			
			// if you include in a menu a call to the method 'aa4D_M_Host_Manage_Info_Report' or 'aa4D_NP_Report_Export_Display',
			// you will be able to start or stop the stored procedure from a remote user.
		End if 
	End if 
End if 
