//%attributes = {"invisible":true}
// Method: aa4D_M_Host_test_remote
var $pathLocalFolder : Text
var $Nb_Minutes : Real
var $typeReports : Integer
var $ptext : Pointer
var $ListProcs : Integer
var myConstantInfo : Text
var $oPath : Object
$oPath:=Folder:C1567(fk desktop folder:K87:19)
$pathLocalFolder:=$oPath.platformPath
$Nb_Minutes:=5
$typeReports:=0
$ptext:=->myConstantInfo
$ListProcs:=0
aa4D_M_Host_Stored_Proc_Remote($pathLocalFolder; $Nb_Minutes; $typeReports; $ptext; $ListProcs)


