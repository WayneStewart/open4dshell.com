//%attributes = {"invisible":true}
// Method: aa4D_M_Host_SP_Scheduler
#DECLARE($vr_every_N_Minutes : Real; $vl_Report_Format : Integer)
If ($vr_every_N_Minutes=0)
	$vr_every_N_Minutes:=5  // by default = 5 minutes
	$vl_Report_Format:=0
End if 
EXECUTE METHOD:C1007("aa4D_NP_Schedule_Reports_Server"; *; $vr_every_N_Minutes; $vl_Report_Format)

