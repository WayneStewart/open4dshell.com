//%attributes = {"invisible":true,"shared":true}
// Method: aa4D_M_Host_Stored_Proc_Remote
#DECLARE($pathLocalFolder : Text; $Nb_Minutes : Real; $typeReports : Integer; $ptext : Pointer; $ListProcs : Integer)
var $pathLocalFolder : Text
var $Nb_Minutes : Real
var vb_FolderPath_OK : Boolean
var $Nb_Params : Integer
var $oPathFolder : Object
ARRAY TEXT:C222($at_Components; 0)
COMPONENT LIST:C1001($at_Components)
If (Find in array:C230($at_Components; "4D_Info_Report@")>0)
	$Nb_Params:=Count parameters:C259
	If (Length:C16($pathLocalFolder)<6)
		aa4D_M_Host_Change_Folder($pathLocalFolder)
	End if 
	EXECUTE METHOD:C1007("aa4D_M_Folder_Rep_GetPath_local"; vb_FolderPath_OK; ->$pathLocalFolder)
	If ($Nb_Minutes=0)
		$Nb_Minutes:=5  // default
	End if 
	If ((vb_FolderPath_OK) & ($Nb_Minutes>0))
		Repeat 
			Case of 
				: ($Nb_Params<=3)
					EXECUTE METHOD:C1007("aa4D_NP_Util_CreateReport"; *; 1; $typeReports)
					
				: ($Nb_Params=4)
					EXECUTE METHOD:C1007("aa4D_NP_Util_CreateReport"; *; 1; $typeReports; $ptext)
					
				: ($Nb_Params=5)
					EXECUTE METHOD:C1007("aa4D_NP_Util_CreateReport"; *; 1; $typeReports; $ptext; $ListProcs)
			End case 
			DELAY PROCESS:C323(Current process:C322; $Nb_Minutes*3600)
		Until ($Nb_Minutes=0)
	End if 
End if 
