If (Shift down:C543)
	TRACE:C157
End if 

aa4D_H__Startup

SET MENU BAR:C67(2)

